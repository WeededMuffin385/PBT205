import {StrictMode} from 'react'
import {createRoot} from 'react-dom/client'
import './index.css'
import App from './app/App.tsx'
import {CookiesProvider} from "react-cookie";

createRoot(document.getElementById('root')!).render(
    <StrictMode>
        <CookiesProvider>
            <App/>
        </CookiesProvider>
    </StrictMode>,
)
